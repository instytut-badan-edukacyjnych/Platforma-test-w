title = "To jest jedynie DEMO raportu!";
expl0 = "To co teraz widzisz, jest przykładem raportu, jaki może zostać wygenerowany przez aplikację w momencie zakończenia badania.";
expl1 = "Autorzy konkretnych testów mogą zaprojektować zawartość tej strony w dowolny sposób wedle własnego uznania. Możliwe jest umieszczanie w raporcie w zasadzie dowolnych treści, jak np. poniższe losowe wykresy.";
expl2 = "Szablony raportów, takie jak ten obecnie widoczny, tworzone są za pomocą HTML, JavaScript i CSS, podobnie jak strony internetowe. Ten szablon używa biblioteki jQuery (http://jquery.com/) oraz biblioteki Protovis (http://mbostock.github.io/protovis/), dzięki której wygenerowane zostały powyższe wykresy. Możliwe jest też użycie innych bibliotek.";
expl3 = "W momencie kiedy zostaną przeprowadzone właściwe badania, aplikacja dostarczy do raportu prawdziwe wyniki badania. Autor testu powinien zaprojektować raport tak, aby rozsądnie owe wyniki zaprezentować.";
expl4 = "Raport może zawierać wiele stron, a nawet elementy interaktywne. Dla przykładu, spróbuj nacisnąć poniższy przycisk.";
expl5 = "Aplikacja daje możliwość zapisania raportu w postaci pliku PDF, i np. wysłania go email\'em lub wydrukowania go. Oczywiście, w takim przypadku, utracone zostają wszystkie aspekty interaktywne. Autorzy testów mogą ustalić odpowiedni zestaw treści do wydrukowania wedle własnego uznania.";
msg0  = "Udało się!\n\nTo oczywiście jest zwykła wiadomość, jednak przycisk mógł wykonać dowolną akcję. Mógł np. załadować nowe dane do wykresu, uaktualnić test raportu, czy przełączyć widok na zupełnie inną stronę.";

